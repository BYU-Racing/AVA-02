import os

# EB provides these environment variables when DB is attached
RDS_HOSTNAME = os.getenv('RDS_HOSTNAME')
RDS_PORT = os.getenv('RDS_PORT', '5432')
RDS_DB_NAME = os.getenv('RDS_DB_NAME', 'ebdb')
RDS_USERNAME = os.getenv('RDS_USERNAME')
RDS_PASSWORD = os.getenv('RDS_PASSWORD')

# Build connection string
if RDS_HOSTNAME:
    DATABASE_URL = f"postgresql://{RDS_USERNAME}:{RDS_PASSWORD}@{RDS_HOSTNAME}:{RDS_PORT}/{RDS_DB_NAME}"
else:
    # Fallback for local development
    DATABASE_URL = os.getenv(
        "DATABASE_URL",
        "postgresql://evangelion:password@localhost/postgres"
    )