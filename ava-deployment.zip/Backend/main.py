from fastapi import FastAPI
from fastapi.concurrency import asynccontextmanager
from .endpoints import drive, driver, data
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from . import crud, models, schemas
from .database import SessionLocal, engine

# Only create tables if database is available (skip if RDS not configured yet)
try:
    models.Base.metadata.create_all(bind=engine)
except Exception as e:
    print(f"Warning: Could not create database tables: {e}")

#fastapi dev main.py

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],  
)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# API health check endpoint
@app.get("/api/health")
def health_check():
    return {"status": "healthy", "message": "Special thanks from: Coleman Hardy, Landon Wheeler, Connor Mabey, Bryce Whitworth, Braden Toone, Bradford Bawden, and the rest of the BYU Racing Electronics Team"}

# Include routers from different endpoint files
app.include_router(drive.router, prefix="/api")
app.include_router(driver.router, prefix="/api")
app.include_router(data.router, prefix="/api")

# Mount static files LAST (catch-all route)
app.mount("/", StaticFiles(directory="Frontend/ava-02/build", html=True), name="static")
