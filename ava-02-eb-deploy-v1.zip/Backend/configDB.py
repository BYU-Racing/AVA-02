import os

def _get_env(name: str, default: str | None = None) -> str | None:
    v = os.getenv(name)
    return v if v not in (None, "") else default

RDS_HOSTNAME = _get_env("RDS_HOSTNAME")
RDS_PORT     = _get_env("RDS_PORT", "5432")
RDS_DB_NAME  = _get_env("RDS_DB_NAME", "ebdb")
RDS_USERNAME = _get_env("RDS_USERNAME")
RDS_PASSWORD = _get_env("RDS_PASSWORD")

# IMPORTANT: DATABASE_URL must ALWAYS be defined (so imports never fail)
if RDS_HOSTNAME and RDS_USERNAME and RDS_PASSWORD:
    DATABASE_URL = f"postgresql://{RDS_USERNAME}:{RDS_PASSWORD}@{RDS_HOSTNAME}:{RDS_PORT}/{RDS_DB_NAME}"
else:
    # Local fallback (or use your own local env var)
    DATABASE_URL = _get_env("DATABASE_URL", "postgresql://evangelion:password@localhost/postgres")
